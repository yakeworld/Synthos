#!/usr/bin/env python3
"""Batch enhance + download references for all papers."""
import sys, os, subprocess, time

BASE = "/media/yakeworld/sda2/Synthos/outputs/papers"
TOOL = "/media/yakeworld/sda2/Synthos/tools/paper-manager"
PY = "/usr/bin/python3"
ENV = os.environ.copy()
if not ENV.get("MEDDATA_USERNAME") or not ENV.get("MEDDATA_PASSWORD"):
    print("⚠️  MEDDATA_USERNAME/MEDDATA_PASSWORD not set in env")

# Papers needing reference update: (dir, max_download, upload_to_project)
PAPERS = [
    ("pd-dysphagia-2026",    15, "4a0f1345"),   # PD project
    ("vog-vestibular-review", 15, "c0bba510"),   # VOR project  
    ("vor-digital-twin",      15, "c0bba510"),   # VOR project
    ("eye-tracking-4d",       12, "c0bba510"),   # VOR project
    ("vor-sparse-modular",     8, "c0bba510"),   # VOR project
]

for paper_dir, limit, project_id in PAPERS:
    bibs = [f for f in os.listdir(f"{BASE}/{paper_dir}") if f.endswith('.bib')]
    if not bibs:
        print(f"\n=== {paper_dir}: no .bib found ===")
        continue
    
    bib_path = f"{BASE}/{paper_dir}/{bibs[0]}"
    out_dir = f"{BASE}/{paper_dir}/enhanced_refs"
    
    print(f"\n=== {paper_dir} → {project_id} (limit={limit}) ===")
    
    # Step 1: Enhance metadata (fast)
    cmd = [PY, "main.py", "enhance", bib_path, "-o", out_dir,
           "--limit", str(limit), "--no-download"]
    t0 = time.time()
    r = subprocess.run(cmd, cwd=TOOL, capture_output=True, text=True, timeout=120, env=ENV)
    elapsed = time.time() - t0
    print(f"  Enhance: {elapsed:.1f}s | {r.stdout.strip().split(chr(10))[-1] if r.stdout else '?'}")
    
    # Step 2: Download PDFs
    cmd2 = [PY, "main.py", "enhance", bib_path, "-o", out_dir,
            "--limit", str(limit)]
    t0 = time.time()
    r2 = subprocess.run(cmd2, cwd=TOOL, capture_output=True, text=True, timeout=300, env=ENV)
    elapsed2 = time.time() - t0
    print(f"  Download: {elapsed2:.1f}s | {r2.stdout.strip().split(chr(10))[-1] if r2.stdout else '?'}")
    
    # Step 3: Upload PDFs to NotebookLM
    pdf_dir = f"{out_dir}/pdfs"
    if os.path.isdir(pdf_dir):
        uploaded = 0
        for fname in os.listdir(pdf_dir):
            if fname.endswith('.pdf'):
                pdf_path = f"{pdf_dir}/{fname}"
                if os.path.getsize(pdf_path) > 1000:
                    title = f"ref-{fname.replace('.pdf','')}"
                    up_cmd = f"notebooklm source add '{pdf_path}' --title '{title}' -n {project_id} --type file 2>/dev/null"
                    up_r = subprocess.run(up_cmd, shell=True, capture_output=True, text=True, timeout=30)
                    if up_r.returncode == 0:
                        uploaded += 1
                    time.sleep(0.5)
        print(f"  Uploaded: {uploaded} PDFs to {project_id}")

print("\n✅ ALL PAPERS DONE!")
