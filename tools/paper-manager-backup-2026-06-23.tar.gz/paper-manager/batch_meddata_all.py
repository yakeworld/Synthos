#!/usr/bin/env python3
"""
Batch download ALL reference DOIs via meddata-enabled racing engine.
Runs 5 concurrent downloads. Uploads to NotebookLM on success.
"""
import os, re, subprocess, time, sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

BASE = "/media/yakeworld/sda2/Synthos/outputs/papers"
TOOL = "/media/yakeworld/sda2/Synthos/tools/paper-manager"
ENV = os.environ.copy()
if not ENV.get("MEDDATA_USERNAME") or not ENV.get("MEDDATA_PASSWORD"):
    print("⚠️  MEDDATA_USERNAME/MEDDATA_PASSWORD not set in env")

PAPERS = {
    "bppv-otoconia-simulation": "95509a49",
    "cuteye-model": "468528f8",
    "iris-3d-anatomical-opt": "6fec2ba0",
    "iris-yolo": "b6698e12",
    "pd-dysphagia-2026": "4a0f1345",
    "pima-crispdm": "b54348f4",
    "portable-et-r2": "ac35b589",
    "vog-vestibular-review": "c0bba510",
    "vor-sparse-modular": "c0bba510",
    "vor-digital-twin": "c0bba510",
    "eye-tracking-4d": "c0bba510",
}

def extract_dois(bib_path):
    dois = set()
    with open(bib_path) as f:
        for line in f:
            m = re.search(r'doi\s*=\s*[\{\"]?(10\.\d{4,}/[^,}\"\s]+)', line, re.I)
            if m:
                dois.add(m.group(1).strip())
    return sorted(dois)

def download_and_upload(doi, paper_dir, project_id):
    """Download one DOI and upload to NotebookLM if successful."""
    pdf_dir = f"{BASE}/{paper_dir}/pdfs"
    os.makedirs(pdf_dir, exist_ok=True)
    
    fname = doi.replace('/', '_').replace('.', '-') + ".pdf"
    out = f"{pdf_dir}/{fname}"
    
    # Skip if already exists
    if os.path.exists(out) and os.path.getsize(out) > 1000:
        return f"⏭ {doi[:45]}"
    
    # Download via racing engine (Sci-Hub → LibGen → MedData)
    cmd = f"cd {TOOL} && python3 download_one.py '{doi}' '{out}'"
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=90, env=ENV)
    
    if os.path.exists(out) and os.path.getsize(out) > 1000:
        sz = os.path.getsize(out)
        # Upload to NotebookLM
        title = f"ref-{fname.replace('.pdf','')}"
        up = subprocess.run(
            f"notebooklm source add '{out}' --title '{title}' -n {project_id} --type file 2>/dev/null",
            shell=True, capture_output=True, text=True, timeout=30)
        if up.returncode == 0:
            return f"✅ {doi[:45]} → {sz//1024}KB uploaded"
        else:
            return f"✅ {doi[:45]} → {sz//1024}KB (upload failed)"
    else:
        return f"❌ {doi[:45]}"


def main():
    total_ok = 0
    total_fail = 0
    
    for paper_dir, project_id in sorted(PAPERS.items()):
        bibs = list(Path(f"{BASE}/{paper_dir}").glob("*.bib"))
        if not bibs:
            continue
        
        dois = extract_dois(str(bibs[0]))
        if not dois:
            continue
        
        print(f"\n{'='*60}")
        print(f"📁 {paper_dir} → {project_id} ({len(dois)} DOIs)")
        print(f"{'='*60}")
        
        results = []
        with ThreadPoolExecutor(max_workers=5) as pool:
            fmap = {}
            for doi in dois:
                fmap[pool.submit(download_and_upload, doi, paper_dir, project_id)] = doi
            
            for f in as_completed(fmap, timeout=600):
                try:
                    msg = f.result(timeout=5)
                    results.append(msg)
                    if msg.startswith('✅') or msg.startswith('⏭'):
                        total_ok += 1
                    else:
                        total_fail += 1
                    print(f"  {msg}")
                except Exception as e:
                    doi = fmap[f]
                    print(f"  ❌ {doi[:45]} (exception: {e})")
                    total_fail += 1
        
        # Show project source count
        r = subprocess.run(f"notebooklm source list -n {project_id} 2>/dev/null | grep -c '📄'",
                          shell=True, capture_output=True, text=True, timeout=15)
        count = r.stdout.strip()
        print(f"  📊 {paper_dir} → {project_id} now has {count} sources")
    
    print(f"\n{'='*60}")
    print(f"✅ ALL DONE: {total_ok} OK, {total_fail} failed")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
